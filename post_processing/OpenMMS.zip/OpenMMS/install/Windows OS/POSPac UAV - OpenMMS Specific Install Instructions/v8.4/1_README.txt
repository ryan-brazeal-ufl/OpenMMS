Install POSPac UAV v8.4 SP2 (Download from Applanix Support Website)
View the other directories found here and read the README files and copy the required files to where they need to go
Open POSPac UAV Application
Click File --> Options
Click the Import and Process section:
	- select 'Load all events'
	- check 'Show event labels on Plan and 3D views'
	- check 'Use real-time Reference to Primary GNSS lever arm standard deviation for APX products' ***IMPORTANT***
Click OK
On the Project Tab in POSPac UAV, click New Project
The example OpenMMS template should be visible, select the template, click OK
On the Help Tab in POSPac UAV, click Software License Utility
	- If no license information appears you need to specify the license server address (if applicable)
	- Click 'License Server'
	- In the License Servers textbox, type the server name or server IP address, click 'Add'
	- Click Save, then close the dialog and get back to the POSPac Software License Utility dialog box
	- Click 'Refresh License', license information should now be visible
	- Close the dialog
POSPac UAV has now been configured