Copy all of the files in this directory to:

C:\ProgramData\Applanix\User Format Profiles 
