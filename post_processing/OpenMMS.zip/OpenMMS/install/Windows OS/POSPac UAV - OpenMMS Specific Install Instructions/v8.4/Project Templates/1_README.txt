Copy the file(s) in this directory to: 
Example below: (the path will be different on each computer depending on the username as well as the version of POSPac UAV being used)

C:\Users\Ryan_Brazeal\AppData\Roaming\Applanix\POSPac UAV\8.4